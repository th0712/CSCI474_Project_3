# CSCI474_Project_3

Compiling:
	"gcc main.c"

Running (Make sure "Output.txt" does not exist in your directory before running):
	"./a.out"

Output:
- 5 Random files are generated at run time (If they don't exist yet).

Outputs results from Table 11.2 in console, outputs random text file output in a 
text file called "Output.txt"

IMPORTANT - DELETE "Output.txt" BEFORE re-running the software